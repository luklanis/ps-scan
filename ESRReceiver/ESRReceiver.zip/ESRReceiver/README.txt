Windows
-------
Double-click ESRReceiver.jar to start the server application.

OSX, Linux
----------
Double-click ESRReceiver.jar to start the server application.

The Java SE runtime environment is needed to use this program.
Mac and Windows users can go to

http://www.java.com/en/download/manual.jsp

to download the runtime environment.
Linux (Ubuntu) users type

sudo apt-get install openjdk-6-jre
or
sudo apt-get install openjdk-7-jre

to install the needed packages.